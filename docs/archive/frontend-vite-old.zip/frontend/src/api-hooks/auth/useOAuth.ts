import { useSignIn } from "@clerk/react";
import { useNavigate } from "react-router-dom";
import { ApiError, type OAuthProvider } from "../../api/auth";
import { CLERK_PUBLISHABLE_KEY } from "../../context/ClerkSetup";

const providerNames: Record<OAuthProvider, string> = {
  google: "Google",
};

// "login" signs in (or up). "connect" attaches the account to the signed-in user.
export type OAuthMode = "login" | "connect";

// Sends the browser to Google through Clerk. It comes back to /sso-callback.
function useClerkOAuth() {
  const { signIn } = useSignIn();
  const navigate = useNavigate();
  return async (
    provider: OAuthProvider,
    mode: OAuthMode = "login",
  ): Promise<string> => {
    const query =
      mode === "connect" ? `?mode=connect&provider=${provider}` : "";
    const { error } = await signIn.sso({
      strategy: `oauth_${provider}`,
      redirectCallbackUrl: `/sso-callback${query}`,
      redirectUrl: `/sso-callback/complete${query}`,
    });
    // A Clerk session left over from an unfinished sign-in: just finish it.
    if (error?.code === "session_exists") {
      navigate(`/sso-callback/complete${query}`);
    } else if (error) {
      throw new ApiError(error.longMessage ?? error.message, 400);
    }
    // The page is navigating away; keep the button's spinner until it does.
    return new Promise<string>(() => {});
  };
}

function useOAuthUnavailable() {
  return async (provider: OAuthProvider): Promise<string> => {
    throw new ApiError(
      `${providerNames[provider]} sign-in isn't set up yet. Use your email instead.`,
      501,
    );
  };
}

export const OAUTH_ENABLED = Boolean(CLERK_PUBLISHABLE_KEY);

// Chosen once at load (the key can't change at runtime), so hook order stays stable.
export const useOAuth = OAUTH_ENABLED ? useClerkOAuth : useOAuthUnavailable;
