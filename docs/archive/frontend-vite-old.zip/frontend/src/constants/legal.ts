// Shown on the Privacy Policy and Terms of Service. The address must receive mail.
export const LEGAL_CONTACT_EMAIL = "quickhotels247@gmail.com";
