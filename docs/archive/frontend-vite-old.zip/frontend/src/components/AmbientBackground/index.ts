export { default } from "./AmbientBackground";
