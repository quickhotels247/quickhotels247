import type { NavItem } from "../DashboardLayout";

// Sidebar entries for the admin dashboard.
export const navItems: NavItem[] = [
  {
    label: "Overview",
    to: "/admin",
    icon: "space_dashboard",
    description: "Customers and admin activity at a glance.",
  },
  {
    label: "Customers",
    to: "/admin/users",
    icon: "group",
    description: "Everyone who has signed up.",
  },
  {
    label: "Admins",
    to: "/admin/admins",
    icon: "admin_panel_settings",
    description: "Your password and the admin team.",
  },
];
