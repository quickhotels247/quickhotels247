export { default } from "./RequireAdmin";
