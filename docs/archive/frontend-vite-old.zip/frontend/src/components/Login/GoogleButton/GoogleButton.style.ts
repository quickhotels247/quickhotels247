export const styles = {
  root: "flex flex-col gap-space-md",
  button:
    "w-full inline-flex items-center justify-center gap-2.5 px-space-md py-3 rounded-full bg-surface-container-lowest border border-outline-variant/70 text-on-surface font-label-md text-label-md font-semibold shadow-sm hover:bg-surface-container-low hover:border-outline-variant transition-colors disabled:opacity-60 disabled:pointer-events-none",
  logo: "w-[18px] h-[18px] shrink-0",
  spinner: "material-symbols-outlined text-[18px] animate-spin",
  divider:
    "flex items-center gap-space-sm font-label-sm text-label-sm text-outline before:h-px before:flex-1 before:bg-outline-variant/50 after:h-px after:flex-1 after:bg-outline-variant/50",
};
