import ProviderLogo from "../../ProviderLogo";
import { styles } from "./GoogleButton.style";

interface GoogleButtonProps {
  onClick: () => void;
  pending: boolean;
  disabled: boolean;
}

// "Continue with Google", then an "or" divider above the email form.
export default function GoogleButton({ onClick, pending, disabled }: GoogleButtonProps) {
  return (
    <div className={styles.root}>
      <button type="button" className={styles.button} disabled={disabled} onClick={onClick}>
        {pending ? (
          <span className={styles.spinner} aria-hidden="true">progress_activity</span>
        ) : (
          <ProviderLogo provider="google" className={styles.logo} />
        )}
        <span>Continue with Google</span>
      </button>
      <div className={styles.divider}>or use your email</div>
    </div>
  );
}
