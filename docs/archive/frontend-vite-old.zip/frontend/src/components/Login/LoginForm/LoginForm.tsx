import { useState, type FormEvent } from "react";
import { useSignIn } from "@clerk/react";
import { CLERK_PUBLISHABLE_KEY } from "../../../context/ClerkSetup";
import { useOAuth } from "../../../api-hooks/auth";
import TextField from "../../TextField";
import GoogleButton from "../GoogleButton";
import PasswordStep from "../SignupForm/PasswordStep";
import VerifyStep from "../SignupForm/VerifyStep";
import { focusFirstInvalid } from "../focusFirstInvalid";
import { useRequest } from "../useRequest";
import { styles } from "./LoginForm.style";

interface LoginFormProps {
  onSwitch: () => void;
  onDone: () => void;
}

// signIn: email and password. verify: Clerk asks for an emailed code (new device).
// forgot → resetCode → newPassword: password reset by emailed code.
type View = "signIn" | "verify" | "forgot" | "resetCode" | "newPassword";
type Field = "email" | "password";

const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const RESEND_WAIT_MS = 30_000;

type ClerkResult = { error: { code?: string; message: string; longMessage?: string } | null };

// Clerk returns errors instead of throwing; turn them into messages for the form.
function check(result: ClerkResult) {
  if (!result.error) return;
  // A Clerk session from an earlier sign-in: finish that one instead.
  if (result.error.code === "session_exists") {
    window.location.assign("/sso-callback/complete");
    throw new Error("You're already signed in. Opening your account…");
  }
  throw new Error(result.error.longMessage ?? result.error.message);
}

export default function LoginForm(props: LoginFormProps) {
  if (!CLERK_PUBLISHABLE_KEY) {
    return <p role="alert">Sign-in is unavailable. Please try again later.</p>;
  }
  return <ClerkLoginForm {...props} />;
}

function ClerkLoginForm({ onSwitch }: LoginFormProps) {
  const { signIn } = useSignIn();
  const startOAuth = useOAuth();
  const [view, setView] = useState<View>("signIn");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [touched, setTouched] = useState<Partial<Record<Field, boolean>>>({});
  const [submitted, setSubmitted] = useState(false);
  const [google, setGoogle] = useState(false);
  const [resendAvailableAt, setResendAvailableAt] = useState(0);
  const { busy, error, setError, run } = useRequest();

  const cleanEmail = email.trim().toLowerCase();
  const errors: Record<Field, string> = {
    email: !cleanEmail
      ? "Enter your email."
      : EMAIL_PATTERN.test(cleanEmail) ? "" : "Enter a valid email address.",
    password: view === "signIn" && !password ? "Enter your password." : "",
  };
  const visibleError = (field: Field) =>
    (submitted || touched[field]) && errors[field] ? errors[field] : undefined;
  const touch = (field: Field) => () =>
    setTouched((previous) => ({ ...previous, [field]: true }));

  // The backend turns the Clerk session into a QuickHotels24/7 session there.
  async function finish() {
    check(await signIn.finalize({ navigate: ({ decorateUrl }) => {
      window.location.assign(decorateUrl("/sso-callback/complete"));
    } }));
  }

  async function continueAfterPassword() {
    if (signIn.status === "complete") return finish();
    if (signIn.status === "needs_second_factor" || signIn.status === "needs_client_trust") {
      await sendSignInCode();
      setView("verify");
      return;
    }
    throw new Error("This account needs a sign-in step we don't support yet. Please contact support.");
  }

  async function sendSignInCode() {
    check(await signIn.mfa.sendEmailCode());
    setResendAvailableAt(Date.now() + RESEND_WAIT_MS);
  }

  async function sendResetCode() {
    check(await signIn.resetPasswordEmailCode.sendCode());
    setResendAvailableAt(Date.now() + RESEND_WAIT_MS);
  }

  function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setSubmitted(true);
    if (errors.email || errors.password) {
      focusFirstInvalid(event.currentTarget);
      return;
    }
    if (view === "forgot") {
      void run(async () => {
        check(await signIn.create({ identifier: cleanEmail }));
        await sendResetCode();
        setView("resetCode");
      });
      return;
    }
    void run(async () => {
      check(await signIn.password({ identifier: cleanEmail, password }));
      await continueAfterPassword();
    });
  }

  async function continueWithGoogle() {
    setGoogle(true);
    await run(() => startOAuth("google"));
    setGoogle(false);
  }

  function goTo(next: View) {
    void signIn.reset();
    setError("");
    setSubmitted(false);
    setTouched({});
    setPassword("");
    setView(next);
  }

  if (view === "verify") {
    return (
      <VerifyStep
        email={cleanEmail}
        resendAvailableAt={resendAvailableAt}
        onVerify={async (code) => {
          check(await signIn.mfa.verifyEmailCode({ code }));
          await finish();
        }}
        onResend={sendSignInCode}
        onChangeEmail={() => goTo("signIn")}
      />
    );
  }
  if (view === "resetCode") {
    return (
      <VerifyStep
        email={cleanEmail}
        resendAvailableAt={resendAvailableAt}
        onVerify={async (code) => {
          check(await signIn.resetPasswordEmailCode.verifyCode({ code }));
          setView("newPassword");
        }}
        onResend={sendResetCode}
        onChangeEmail={() => goTo("forgot")}
      />
    );
  }
  if (view === "newPassword") {
    return (
      <PasswordStep
        email={cleanEmail}
        onCreate={async (newPassword) => {
          check(await signIn.resetPasswordEmailCode.submitPassword({ password: newPassword }));
          await continueAfterPassword();
        }}
        onStartOver={() => goTo("forgot")}
      />
    );
  }

  const forgot = view === "forgot";
  return (
    <form className={styles.form} onSubmit={submit} noValidate>
      {!forgot && (
        <GoogleButton onClick={continueWithGoogle} pending={google} disabled={busy} />
      )}
      {forgot && (
        <p className={styles.hint}>
          Enter your account's email and we'll send you a code to choose a new password.
        </p>
      )}
      {error && (
        <p className={styles.errorBanner} role="alert">
          {error}
        </p>
      )}

      <fieldset className={styles.fields} disabled={busy}>
        <TextField
          label="Email"
          name="email"
          type="email"
          autoComplete="email"
          inputMode="email"
          autoFocus
          value={email}
          onValueChange={setEmail}
          onBlur={touch("email")}
          error={visibleError("email")}
        />
        {!forgot && (
          <div className={styles.passwordField}>
            <TextField
              label="Password"
              name="password"
              type="password"
              autoComplete="current-password"
              value={password}
              onValueChange={setPassword}
              onBlur={touch("password")}
              error={visibleError("password")}
            />
            <button type="button" className={styles.forgotLink} onClick={() => goTo("forgot")}>
              Forgot password?
            </button>
          </div>
        )}
      </fieldset>

      {/* Clerk's bot protection renders here when it needs to. */}
      <div id="clerk-captcha" />

      <button className={styles.submit} type="submit" disabled={busy}>
        {busy && !google && (
          <span className={styles.spinner} aria-hidden="true">progress_activity</span>
        )}
        {forgot
          ? busy ? "Sending code..." : "Send reset code"
          : busy && !google ? "Logging in..." : "Log in"}
      </button>

      {forgot ? (
        <p className={styles.switchText}>
          Remembered it?
          <button type="button" className={styles.switchButton} onClick={() => goTo("signIn")}>
            Back to log in
          </button>
        </p>
      ) : (
        <p className={styles.switchText}>
          Don't have an account?
          <button type="button" className={styles.switchButton} onClick={onSwitch}>
            Sign up
          </button>
        </p>
      )}
    </form>
  );
}
