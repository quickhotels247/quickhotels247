import { formStyles } from "../AuthForm.style";

export const styles = {
  ...formStyles,
  passwordField: "flex flex-col gap-1.5",
  forgotLink:
    "self-end font-label-sm text-label-sm font-semibold text-primary hover:underline underline-offset-4 rounded focus-visible:outline focus-visible:outline-2 focus-visible:outline-primary",
  hint: "text-center font-body-sm text-body-sm text-on-surface-variant",
};
