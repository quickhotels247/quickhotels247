export { default } from "./PageLoader";
