export { default } from "./StatTile";
