import DashboardLayout from "../DashboardLayout";
import UserMenu from "./UserMenu";
import { navItems } from "./navItems";

// The signed-in customer's account shell.
export default function UserLayout() {
  return (
    <DashboardLayout
      navItems={navItems}
      homeTo="/dashboard"
      sidebarFooter={(collapsed) => <UserMenu collapsed={collapsed} />}
    />
  );
}
