import HeroSection from "./components/HeroSection";

// Placeholder landing page until hotel search is built.
export default function Home() {
  return (
    <div className="flex flex-col w-full">
      <HeroSection />
    </div>
  );
}
