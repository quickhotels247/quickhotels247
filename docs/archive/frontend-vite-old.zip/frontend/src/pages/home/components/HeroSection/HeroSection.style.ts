export const styles = {
  root: "relative w-full flex flex-col items-center",
  glow: "absolute -top-12 left-1/2 -translate-x-1/2 w-[840px] h-[340px] bg-gradient-to-b from-primary-fixed/30 via-secondary-fixed/20 to-transparent blur-3xl pointer-events-none -z-10",
  title:
    "mt-space-md font-display-xl text-display-xl text-center text-on-surface tracking-tight max-w-4xl",
  titleAccent:
    "bg-gradient-to-r from-primary via-primary-container to-secondary bg-clip-text text-transparent",
  subtitle:
    "mt-space-sm font-body-lg text-body-lg text-center text-on-surface-variant max-w-2xl leading-relaxed",
};
