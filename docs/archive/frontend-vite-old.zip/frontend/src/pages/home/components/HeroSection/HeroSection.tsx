import { styles } from "./HeroSection.style";

export default function HeroSection() {
  return (
    <div className={styles.root}>
      <div className={styles.glow} />
      <h1 className={styles.title}>
        Find a stay that fits your trip with{" "}
        <span className={styles.titleAccent}>QuickHotels24/7</span>
      </h1>
      <p className={styles.subtitle}>
        Hotel search and booking are coming soon.
      </p>
    </div>
  );
}
