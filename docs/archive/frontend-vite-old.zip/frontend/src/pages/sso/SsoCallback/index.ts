export { default } from "./SsoCallback";
