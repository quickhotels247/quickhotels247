export { default } from "./SsoComplete";
