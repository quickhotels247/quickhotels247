export const styles = {
  root: "flex flex-col gap-space-lg",
  greeting: "flex flex-col gap-space-xs",
  title:
    "font-headline-lg text-headline-lg-mobile sm:text-headline-lg text-on-surface tracking-tight",
  subtitle: "font-body-lg text-body-lg text-on-surface-variant",
  action:
    "self-start inline-flex items-center gap-1 font-label-md text-label-md font-semibold text-primary hover:underline underline-offset-4",
};
