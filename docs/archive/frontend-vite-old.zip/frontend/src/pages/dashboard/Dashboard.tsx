import { Link } from "react-router-dom";
import { useAuth } from "../../api-hooks/auth";
import { styles } from "./Dashboard.style";

export default function Dashboard() {
  const { user } = useAuth();

  return (
    <div className={styles.root}>
      <div className={styles.greeting}>
        <h2 className={styles.title}>Welcome back, {user?.firstName}</h2>
        <p className={styles.subtitle}>
          Your bookings will appear here once hotel booking launches.
        </p>
      </div>
      <Link to="/dashboard/settings" className={styles.action}>
        Manage your profile and sign-in methods
        <span className="material-symbols-outlined text-[16px]">arrow_forward</span>
      </Link>
    </div>
  );
}
