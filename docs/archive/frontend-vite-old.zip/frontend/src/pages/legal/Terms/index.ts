export { default } from "./Terms";
