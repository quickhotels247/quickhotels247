import { LEGAL_CONTACT_EMAIL } from "../../../constants/legal";
import LegalPage, { legalStyles as s } from "../LegalPage";

// Placeholder until the QuickHotels24/7 booking terms are written and legally reviewed.
export default function Terms() {
  return (
    <LegalPage title="Terms of Service">
      <p>
        Our terms of service for hotel bookings are being prepared. Questions?
        Email{" "}
        <a className={s.link} href={`mailto:${LEGAL_CONTACT_EMAIL}`}>
          {LEGAL_CONTACT_EMAIL}
        </a>
        .
      </p>
    </LegalPage>
  );
}
