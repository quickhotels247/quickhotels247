export { default } from "./Privacy";
