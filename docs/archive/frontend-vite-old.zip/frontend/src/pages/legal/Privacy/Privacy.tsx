import { LEGAL_CONTACT_EMAIL } from "../../../constants/legal";
import LegalPage, { legalStyles as s } from "../LegalPage";

// Placeholder until the QuickHotels24/7 privacy policy is written and legally reviewed.
export default function Privacy() {
  return (
    <LegalPage title="Privacy Policy">
      <p>
        Our privacy policy is being prepared. Questions?
        Email{" "}
        <a className={s.link} href={`mailto:${LEGAL_CONTACT_EMAIL}`}>
          {LEGAL_CONTACT_EMAIL}
        </a>
        .
      </p>
    </LegalPage>
  );
}
