import { useEffect, type ReactNode } from "react";
import { legalStyles, styles } from "./LegalPage.style";

interface LegalPageProps {
  title: string;
  children: ReactNode;
}

// Shared frame for the Privacy Policy and Terms of Service.
export default function LegalPage({ title, children }: LegalPageProps) {
  useEffect(() => {
    document.title = `${title} | QuickHotels24/7`;
    window.scrollTo({ top: 0 });
  }, [title]);

  return (
    <article className={styles.root}>
      <h1 className={styles.title}>{title}</h1>
      <div className={styles.body}>{children}</div>
    </article>
  );
}

interface SectionProps {
  title: string;
  children: ReactNode;
}

export function Section({ title, children }: SectionProps) {
  return (
    <section className={legalStyles.section}>
      <h2 className={legalStyles.heading}>{title}</h2>
      {children}
    </section>
  );
}
