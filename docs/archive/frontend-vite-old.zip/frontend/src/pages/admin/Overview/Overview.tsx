import { adminApi } from "../../../api/admin";
import { useApiData } from "../../../api-hooks/useApiData";
import StatTile from "../../../components/StatTile";
import { formatNumber, formatRelative } from "../../../utils/format";
import { describeAudit } from "../auditLabels";
import { styles } from "./Overview.style";

export default function Overview() {
  const { data, error } = useApiData(() => adminApi.overview(), []);

  if (error) return <p className={styles.pageError}>{error}</p>;
  if (!data) {
    return (
      <p className={styles.loading}>
        <span className={styles.loadingIcon}>progress_activity</span>
        Loading…
      </p>
    );
  }

  return (
    <div className={styles.page}>
      <div className={styles.stats}>
        <StatTile icon="group" label="Customers" value={formatNumber(data.users.total)} hint={`+${formatNumber(data.users.newLast7Days)} in the last 7 days`} />
      </div>

      <section className={styles.card} aria-labelledby="activity-title">
        <div className={styles.header}>
          <h2 id="activity-title" className={styles.title}>Recent admin activity</h2>
        </div>
        {data.recentActivity.length ? (
          <ul className={styles.list}>
            {data.recentActivity.map((entry) => {
              const { icon, text } = describeAudit(entry);
              return (
                <li key={entry.id} className={styles.activity}>
                  <span className={styles.activityIcon}>{icon}</span>
                  <span className="flex-1 min-w-0">
                    <span className={styles.strong}>{entry.adminName ?? "Removed admin"}</span>{" "}
                    <span className={styles.activityText}>{text}</span>
                  </span>
                  <span className={styles.time}>{formatRelative(entry.createdAt)}</span>
                </li>
              );
            })}
          </ul>
        ) : (
          <p className={styles.muted}>Nothing yet.</p>
        )}
      </section>
    </div>
  );
}
