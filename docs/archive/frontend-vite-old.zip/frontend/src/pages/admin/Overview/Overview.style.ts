import { adminStyles } from "../admin.style";

export const styles = {
  ...adminStyles,
  list: "flex flex-col divide-y divide-outline-variant/30",
  activity: "flex items-start gap-space-sm py-2.5 first:pt-0 last:pb-0",
  activityIcon: "material-symbols-outlined text-[18px] text-outline mt-0.5",
  activityText: "font-body-md text-body-md text-on-surface-variant break-words",
  time: "shrink-0 font-label-sm text-label-sm text-outline whitespace-nowrap",
};
