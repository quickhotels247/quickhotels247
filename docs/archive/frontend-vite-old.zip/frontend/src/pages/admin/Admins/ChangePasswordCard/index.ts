export { default } from "./ChangePasswordCard";
