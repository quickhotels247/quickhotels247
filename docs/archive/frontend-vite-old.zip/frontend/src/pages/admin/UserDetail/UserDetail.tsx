import { Link, useParams } from "react-router-dom";
import { adminApi } from "../../../api/admin";
import { useApiData } from "../../../api-hooks/useApiData";
import { formatDate, formatRelative } from "../../../utils/format";
import { styles } from "./UserDetail.style";

// One customer's profile.
export default function UserDetail() {
  const { userId = "" } = useParams();
  const { data, error } = useApiData(() => adminApi.user(userId), [userId]);

  return (
    <div className={styles.page}>
      <Link to="/admin/users" className={styles.back}>
        <span className="material-symbols-outlined text-[18px]">arrow_back</span>
        All customers
      </Link>

      {error && <p className={styles.pageError}>{error}</p>}
      {!data && !error && (
        <p className={styles.loading}>
          <span className={styles.loadingIcon}>progress_activity</span>
          Loading customer…
        </p>
      )}

      {data && (
        <section className={styles.profile} aria-labelledby="user-name">
          <span className={styles.avatar} aria-hidden="true">
            {(data.name || data.email).charAt(0).toUpperCase()}
          </span>
          <div className="min-w-0 flex-1">
            <h2 id="user-name" className={styles.name}>{data.name || data.username}</h2>
            <p className={styles.email}>{data.email}</p>
          </div>
          <dl className={styles.facts}>
            <div><dt className={styles.factLabel}>Username</dt><dd>@{data.username}</dd></div>
            <div><dt className={styles.factLabel}>Signs in with</dt><dd>{data.signedInWith}</dd></div>
            <div><dt className={styles.factLabel}>Joined</dt><dd>{formatDate(data.createdAt)}</dd></div>
            <div><dt className={styles.factLabel}>Last active</dt><dd>{data.lastActiveAt ? formatRelative(data.lastActiveAt) : "Never"}</dd></div>
          </dl>
        </section>
      )}
    </div>
  );
}
