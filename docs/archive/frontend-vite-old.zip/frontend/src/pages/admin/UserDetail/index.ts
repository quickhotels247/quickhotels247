export { default } from "./UserDetail";
