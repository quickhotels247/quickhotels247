import type { AuditEntry } from "@quickhotels/types/admin";

// One line describing an admin action, for the activity list.
export function describeAudit(entry: AuditEntry): { icon: string; text: string } {
  const details = entry.details as Record<string, unknown>;
  switch (entry.action) {
    case "admin.login":
      return { icon: "login", text: "signed in" };
    case "admin.setup":
      return { icon: "person_add", text: "created the first admin account" };
    case "admin.create":
      return { icon: "person_add", text: `added admin ${String(details.email ?? "")}` };
    case "admin.password":
      return { icon: "password", text: "changed their password" };
    default:
      return { icon: "history", text: entry.action };
  }
}
