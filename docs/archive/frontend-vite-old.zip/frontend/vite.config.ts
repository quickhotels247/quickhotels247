import { defineConfig, loadEnv, type UserConfig } from "vite";
import react from "@vitejs/plugin-react";

export default defineConfig(({ mode }) => {
  // A production build must know where the API is; without it the site would
  // quietly call http://localhost:8080 from users' browsers.
  const env = loadEnv(mode, process.cwd(), "VITE_");
  if (mode === "production" && !env.VITE_API_URL) {
    throw new Error("Set VITE_API_URL (the backend address) for production builds.");
  }
  return config;
});

const config = {
  plugins: [react()],
  server: {
    host: "localhost",
    port: 3000,
    strictPort: true,
    open: true,
  },
  preview: {
    host: "localhost",
    port: 3000,
    strictPort: true,
    open: true,
  },
} satisfies UserConfig;
